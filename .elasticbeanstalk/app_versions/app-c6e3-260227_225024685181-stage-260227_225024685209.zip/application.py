#!/usr/bin/env python3
"""
WSGI application entry point for AWS Elastic Beanstalk
"""
import os
import sys

# Add current directory to path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import the FastAPI app
from simple_app import app as application

# For Gunicorn
app = application

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", 8000)))
